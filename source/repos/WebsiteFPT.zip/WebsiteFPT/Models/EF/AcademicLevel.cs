namespace Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AcademicLevel")]
    public partial class AcademicLevel
    {
        public long ID { get; set; }

        [StringLength(50)]
        public string Ielts { get; set; }

        [StringLength(50)]
        public string Major { get; set; }

        public long? IdUser { get; set; }

        public virtual User User { get; set; }
    }
}
