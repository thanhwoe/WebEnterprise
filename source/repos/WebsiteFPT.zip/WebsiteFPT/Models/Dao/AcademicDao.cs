﻿using Models.EF;
using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.Dao
{
    public class AcademicDao
    {
        WebsiteFPTDbContext db = null;
        public AcademicDao()
        {
            db = new WebsiteFPTDbContext();
        }
        public IEnumerable<AcademicLevel> ListAllPaging(int page, int pageSize)
        {
            return db.AcademicLevels.OrderByDescending(x => x.ID).ToPagedList(page, pageSize);
        }
        public long Insert(AcademicLevel entity)
        {
            db.AcademicLevels.Add(entity);
            db.SaveChanges();
            return entity.ID;
        }
        public bool Delete(int id)
        {
            try
            {
                var ada = db.AcademicLevels.Find(id);
                db.AcademicLevels.Remove(ada);
                db.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public List<AcademicLevel> ListAll()
        {
            return db.AcademicLevels.ToList();
        }

    }
}
