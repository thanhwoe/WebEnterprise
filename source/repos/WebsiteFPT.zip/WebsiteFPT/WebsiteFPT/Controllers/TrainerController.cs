﻿using Models.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebsiteFPT.Controllers
{
    public class TrainerController : Controller
    {
        WebsiteFPTDbContext db = null;
        public TrainerController()
        {
            db = new WebsiteFPTDbContext();
        }
        public ActionResult Index()
        {
            var session = (UserLogin)Session[WebsiteFPT.Common.CommonConstants.USER_SSESION];

            var course = db.Enrollments.Where(c => c.IdUser == session.UserID).ToList();

            return View(course);
        }
        public ActionResult Profile()
        {
            var session = (UserLogin)Session[WebsiteFPT.Common.CommonConstants.USER_SSESION];

            var profile = db.Users.Where(c => c.ID == session.UserID).ToList();

            return View(profile);
        }
        public ActionResult Academic()
        {
            var session = (UserLogin)Session[WebsiteFPT.Common.CommonConstants.USER_SSESION];

            var aca = db.AcademicLevels.Where(c => c.ID == session.UserID).ToList();

            return View(aca);
        }
    }
}