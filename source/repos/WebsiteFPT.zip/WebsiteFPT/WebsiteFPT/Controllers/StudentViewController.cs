﻿using Microsoft.AspNet.Identity;
using Models.Dao;
using Models.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebsiteFPT.Areas.Admin.Models;
using WebsiteFPT.Common;
using WebsiteFPT.Models;

namespace WebsiteFPT.Controllers
{
    public class StudentViewController : BaseController
    {
        WebsiteFPTDbContext db = null;
        public StudentViewController()
        {
            db = new WebsiteFPTDbContext();
        }
        public ActionResult Index()
        {
            var session = (UserLogin)Session[WebsiteFPT.Common.CommonConstants.USER_SSESION];

            var course = db.Enrollments.Where(c => c.IdUser == session.UserID).ToList();

            return View(course);
        }
        public ActionResult Profile()
        {
            var session = (UserLogin)Session[WebsiteFPT.Common.CommonConstants.USER_SSESION];

            var profile = db.Users.Where(c => c.ID == session.UserID).ToList();

            return View(profile);
        }
    }
}