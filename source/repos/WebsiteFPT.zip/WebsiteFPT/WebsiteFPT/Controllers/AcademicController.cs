﻿using Models.Dao;
using Models.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebsiteFPT.Controllers
{
    public class AcademicController : Controller
    {
        WebsiteFPTDbContext db = null;
        // GET: Adacamic
        public ActionResult Index(int page = 1, int pageSize = 10)
        {
            var ada = new AcademicDao();
            var model = ada.ListAllPaging(page, pageSize);
            return View(model);
        }
        [HttpGet]
        public ActionResult Create()
        {
            SetViewBag2();
            return View();
        }
        [HttpPost]
        public ActionResult Create(AcademicLevel aca)
        {
            if (ModelState.IsValid)
            {
                var adecamicdao = new AcademicDao();
                long id = adecamicdao.Insert(aca);
                if (id > 0)
                {
                    return RedirectToAction("Index", "Academic");
                }
                else
                {
                    ModelState.AddModelError("", "Add Academic not access");
                }
            }
            return View("Index");
        }
        [HttpDelete]
        public ActionResult Delete(int id)
        {
            new AcademicDao().Delete(id);
            return RedirectToAction("Index");
        }
        public void SetViewBag2(long? selectedId = null)
        {
            db = new WebsiteFPTDbContext();
            var dao = from p in db.Users where p.IdRole == 4 select p;
            ViewBag.IdUser = new SelectList(dao.ToList(), "ID", "UserName", selectedId);
        }

    }
}