﻿using Models.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebsiteFPT.Controllers
{
    public class GetRole
    {

    }
}