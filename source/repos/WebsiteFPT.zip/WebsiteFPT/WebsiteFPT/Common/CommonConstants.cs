﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebsiteFPT.Common
{
    public static class CommonConstants
    {
        public static string USER_SSESION = "USER_SSESION";
    }
}