﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebsiteFPT.Areas.Admin.Controllers
{
    public class FoundController : Controller
    {
        // GET: Admin/Found
        public ActionResult Index()
        {
            return View();
        }
    }
}